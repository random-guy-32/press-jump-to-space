package pressjumptospace.util;

public class Physics {
    public static float gravity = 0.5f;
}
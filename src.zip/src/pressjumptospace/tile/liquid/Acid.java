package pressjumptospace.tile.liquid;

import pressjumptospace.tile.meta.GenericAcidTile;

public class Acid extends GenericAcidTile {
    public Acid() {
        super("tile/acid.png", "Acid");
    }
}

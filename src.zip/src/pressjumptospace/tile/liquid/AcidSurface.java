package pressjumptospace.tile.liquid;

import pressjumptospace.tile.meta.GenericAcidTile;

public class AcidSurface extends GenericAcidTile {
    public AcidSurface() {
        super("tile/acid-top.png", "Acid Surface");
    }
}

package pressjumptospace.tile.liquid;

import pressjumptospace.tile.meta.GooTile;

public class BlueGoo extends GooTile {
    public BlueGoo() {
        super("tile/blue-goo.png", "Blue Goo", new int[] {0, 0, 0, 0}, 0.8f);
    }
}

package pressjumptospace.tile.liquid;

import pressjumptospace.tile.meta.GooTile;

public class GreenGoo extends GooTile {
    public GreenGoo() {
        super("tile/green-goo.png", "Green Goo", new int[] {0, 0, 0, 0}, 0.3f);
    }
}

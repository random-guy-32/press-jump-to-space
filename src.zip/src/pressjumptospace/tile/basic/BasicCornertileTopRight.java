package pressjumptospace.tile.basic;

import pressjumptospace.tile.meta.GenericBasicTile;
import pressjumptospace.tile.meta.SolidTile;

public class BasicCornertileTopRight extends GenericBasicTile {
    public BasicCornertileTopRight() {
        super("tile/basic-cornertile-top-right.png", "Basic Corner Tile (top-right)");
    }
}
package pressjumptospace.tile.basic;

import pressjumptospace.tile.meta.GenericBasicTile;

public class BasicTile extends GenericBasicTile {
    public BasicTile() {
        super("tile/basic-tile.png", "Basic Tile");
    }
}

package pressjumptospace.tile.basic;

import pressjumptospace.tile.meta.GenericBasicTile;
import pressjumptospace.tile.meta.SolidTile;

public class BasicWalltileLeft extends GenericBasicTile {
    public BasicWalltileLeft() {
        super("tile/basic-walltile-left.png", "Basic Wall Tile (left)");
    }
}
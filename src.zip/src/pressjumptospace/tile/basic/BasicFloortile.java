package pressjumptospace.tile.basic;

import pressjumptospace.tile.meta.GenericBasicTile;
import pressjumptospace.tile.meta.SolidTile;

public class BasicFloortile extends GenericBasicTile {
    public BasicFloortile() {
        super("tile/basic-floortile.png", "Basic Floor Tile");
    }
}
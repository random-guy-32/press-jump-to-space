package pressjumptospace.tile.basic;

import pressjumptospace.tile.meta.GenericBasicTile;
import pressjumptospace.tile.meta.SolidTile;

public class BasicInnerCornertileBottomLeft extends GenericBasicTile {
    public BasicInnerCornertileBottomLeft() {
        super("tile/basic-inner-cornertile-bottom-left.png", "Basic Inner Corner Tile (bottom-left)");
    }
}
package pressjumptospace.tile.basic;

import pressjumptospace.tile.meta.GenericBasicTile;
import pressjumptospace.tile.meta.SolidTile;

public class BasicInnerCornertileTopLeft extends GenericBasicTile {
    public BasicInnerCornertileTopLeft() {
        super("tile/basic-inner-cornertile-top-left.png", "Basic Inner Corner Tile (top-left)");
    }
}
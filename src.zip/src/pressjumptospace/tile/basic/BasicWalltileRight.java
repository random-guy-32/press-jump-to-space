package pressjumptospace.tile.basic;

import pressjumptospace.tile.meta.GenericBasicTile;
import pressjumptospace.tile.meta.SolidTile;

public class BasicWalltileRight extends GenericBasicTile {
    public BasicWalltileRight() {
        super("tile/basic-walltile-right.png", "Basic Wall Tile (right)");
    }
}
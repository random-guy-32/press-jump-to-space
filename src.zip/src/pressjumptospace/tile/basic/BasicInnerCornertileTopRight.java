package pressjumptospace.tile.basic;

import pressjumptospace.tile.meta.GenericBasicTile;
import pressjumptospace.tile.meta.SolidTile;

public class BasicInnerCornertileTopRight extends GenericBasicTile {
    public BasicInnerCornertileTopRight() {
        super("tile/basic-inner-cornertile-top-right.png", "Basic Inner Corner Tile (top-right)");
    }
}
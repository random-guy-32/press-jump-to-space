package pressjumptospace.tile.basic;

import pressjumptospace.tile.meta.GenericBasicTile;
import pressjumptospace.tile.meta.SolidTile;

public class BasicInnerCornertileBottomRight extends GenericBasicTile {
    public BasicInnerCornertileBottomRight() {
        super("tile/basic-inner-cornertile-bottom-right.png", "Basic Inner Corner Tile (bottom-right)");
    }
}
package pressjumptospace.tile.basic;

import pressjumptospace.tile.meta.GenericBasicTile;
import pressjumptospace.tile.meta.SolidTile;

public class BasicCeilingtile extends GenericBasicTile {
    public BasicCeilingtile() {
        super("tile/basic-ceilingtile.png", "Basic Ceiling Tile");
    }
}
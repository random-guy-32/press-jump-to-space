package pressjumptospace.tile.basic;

import pressjumptospace.tile.meta.GenericBasicTile;
import pressjumptospace.tile.meta.SolidTile;

public class BasicCornertileTopLeft extends GenericBasicTile {
    public BasicCornertileTopLeft() {
        super("tile/basic-cornertile-top-left.png", "Basic Corner Tile (top-left)");
    }
}
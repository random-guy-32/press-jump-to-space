package pressjumptospace.tile.basic;

import pressjumptospace.tile.meta.GenericBasicTile;
import pressjumptospace.tile.meta.SolidTile;

public class BasicCornertileBottomRight extends GenericBasicTile {
    public BasicCornertileBottomRight() {
        super("tile/basic-cornertile-bottom-right.png", "Basic Corner Tile (bottom-right)");
    }
}
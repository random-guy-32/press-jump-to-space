package pressjumptospace.tile.basic;

import pressjumptospace.tile.meta.GenericBasicTile;
import pressjumptospace.tile.meta.SolidTile;

public class BasicCornertileBottomLeft extends GenericBasicTile {
    public BasicCornertileBottomLeft() {
        super("tile/basic-cornertile-bottom-left.png", "Basic Corner Tile (bottom-left)");
    }
}
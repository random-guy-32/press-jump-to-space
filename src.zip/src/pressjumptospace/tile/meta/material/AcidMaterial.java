package pressjumptospace.tile.meta.material;

import pressjumptospace.tile.meta.Material;

public class AcidMaterial extends Material {
    public AcidMaterial() {}
}

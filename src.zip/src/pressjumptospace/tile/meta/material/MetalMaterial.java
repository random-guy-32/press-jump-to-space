package pressjumptospace.tile.meta.material;

import pressjumptospace.tile.meta.Material;

public class MetalMaterial extends Material {
    public MetalMaterial() {

    }
}

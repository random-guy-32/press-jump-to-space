package pressjumptospace.tile.meta.material;

import pressjumptospace.tile.meta.Material;

public class GooMaterial extends Material {
    public GooMaterial() {}
}

package pressjumptospace.tile.meta;

public abstract class GenericBasicTile extends SolidTile {
    public GenericBasicTile(String sprite, String name) {
        super(Material.Metal, sprite, name);
    }
}
package pressjumptospace.tile.spike;

import pressjumptospace.tile.meta.SpikeTile;

public class UpSpikes extends SpikeTile {
    public UpSpikes() {
        super(new int[] {1, 0, 0, 0}, "tile/spikes-up.png", "Up Spikes");
    }
}

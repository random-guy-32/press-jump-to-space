package pressjumptospace.tile.spike;

import pressjumptospace.tile.meta.SpikeTile;

public class LeftSpikes extends SpikeTile {
    public LeftSpikes() {
        super(new int[] {0, 0, 0, 1}, "tile/spikes-left.png", "Left Spikes");
    }
}

package pressjumptospace.tile.spike;

import pressjumptospace.tile.meta.SpikeTile;

public class SpikyBall extends SpikeTile {
    public SpikyBall() {
        super(new int[] {1, 1, 1, 1}, "tile/spiky-ball.png", "Spiky Ball");
    }
}

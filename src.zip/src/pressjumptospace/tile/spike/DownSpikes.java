package pressjumptospace.tile.spike;

import pressjumptospace.tile.meta.SpikeTile;

public class DownSpikes extends SpikeTile {
    public DownSpikes() {
        super(new int[] {0, 0, 1, 0}, "tile/spikes-down.png", "Down Spikes");
    }
}

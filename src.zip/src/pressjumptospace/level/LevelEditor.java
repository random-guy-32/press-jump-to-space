package pressjumptospace.level;

import pressjumptospace.entity.CursorSpawner;
import pressjumptospace.entity.CursorTile;
import pressjumptospace.main.Game;

public class LevelEditor {
    public static CursorTile selectedTile;
    public static CursorSpawner selectedSpawner;
    public static boolean eraser = false;
    public static boolean spawnpoint = false;
    public static boolean pressed = false;
    public static int mode = 0;

    public static void toggleMode() {
        LevelEditor.mode = (LevelEditor.mode == 0) ? 1 : 0;

        Game.paletteFrame.setTitle((LevelEditor.mode == 0) ? "Tiles" : "Entities");
    }
}
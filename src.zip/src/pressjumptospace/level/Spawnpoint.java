package pressjumptospace.level;

public class Spawnpoint {
    public static final String sprite = "entity/player-spawnpoint.png";
    public static int x;
    public static int y;
    public static boolean set = false;
}
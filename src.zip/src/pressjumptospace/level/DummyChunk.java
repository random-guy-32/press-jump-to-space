package pressjumptospace.level;

public abstract class DummyChunk {
    // i'm ashamed, but it works like a charm
    public static final Chunk c = new Chunk();
}
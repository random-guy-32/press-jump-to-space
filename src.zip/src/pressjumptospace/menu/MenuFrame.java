package pressjumptospace.menu;

import javax.swing.*;

public class MenuFrame extends JFrame {
    public MenuFrame(String title_) {
        super(title_);
    }

    public static int objWidth = 300;
    public static int objHeight = 128;
}
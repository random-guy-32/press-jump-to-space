package pressjumptospace.render;

public class PaletteSwitchButton {
    public static String sprite = "gui/palette-mode-switch.png";
}

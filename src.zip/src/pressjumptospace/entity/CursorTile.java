package pressjumptospace.entity;

import pressjumptospace.entity.meta.CursorEntity;
import pressjumptospace.level.Level;

public class CursorTile extends CursorEntity {
    public CursorTile(int x_, int y_, short tileID_) {
        super(x_, y_, (tileID_ == -16) ? CursorTile.getSprite() : Level.tileset.get(tileID_).sprite.src);
        id = tileID_;
    }
    public short id;


}
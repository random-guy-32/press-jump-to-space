package pressjumptospace.entity;

public class Eraser {
    public static final String sprite = "gui/eraser.png";
}
